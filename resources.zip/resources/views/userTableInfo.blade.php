
  
   <table class='table table-borderd search-result-table '> 
    @foreach ($user->orders as  $value) 
               <tr> <td>@lang('main.name')          </td> <td> {{$user->full_name }}               </td> </tr> 
               <tr> <td> @lang('main.phone')        </td> <td> {{$user->phone }}                   </td> </tr> 
               <tr> <td> @lang('main.type')         </td> <td>  {{ $value->ar_name}}               </td> </tr> 
               <tr> <td> @lang('main.discount')     </td> <td>  {{$value->discount}}  %            </td> </tr> 
               <tr> <td> @lang('main.price')     </td> <td>  {{$value->price}}              </td> </tr> 
               <tr> <td>  @lang('main.limitations') </td> <td> @lang('main.'.$value->limitations)  </td> </tr>             
               <tr> <td> @lang('main.end_date')     </td> <td> {{$value->date_to}}                 </td> </tr>
            
               @foreach ($user->useOrders as  $userOrder)     
               
   <tr> <td> @lang('main.date_of_last_use')</td> <td> {{$userOrder->date_of_used}} </td> <td>         


               <tr> <td>  @lang('main.frequency_availability')   </td> <td>
                     

                @if ($userOrder->card_limit =='unlimited')

                       @lang('main.'.$userOrder->card_limit)
                @else
                {{$userOrder->card_limit}}
                @endif
                    
                    </td> </tr>
          
               <tr> <td colspan='2'>  
         
                @if ( today()->toDateString() <= $value->date_to)
               
                
                  @if ($userOrder->status ==  'active' && ($userOrder->card_limit >  0 || $userOrder->card_limit =='unlimited') ) 
                   
 <a href=""  class="btn btn-info shadow-lg" data-toggle="modal" data-target="#deleteModel-{{$userOrder->id}}" title="@lang('main.use_discount')">
         @lang('main.use_discount')
   </a>

           <div class="modal animated--grow-in" tabindex="-1" role="dialog" id="deleteModel-{{$userOrder->id}}">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body border-left-success">
                                    
                                    <h5 class="font-weight-bold"> @lang('main.ask_using_discount') </h5>
                                    <h6 class="h5">{{$user->full_name }}</h6>
                    
                                    
                                </div>
                                <div class="modal-footer">
                                  <form action="{{ route('useCardSubmit',$userOrder->id) }}" method="POST">
                                        @csrf
                                        @method('PATCH')
                                        <button type="submit" class="btn btn-success mr-1"> @lang('main.approval') </button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> @lang('main.cancel') </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
 
                 @else
                          @lang('main.disabled')
                  @endif
          

          @else
                @lang('main.disabled')   
          @endif

             </td> 
         </tr>  
         @endforeach  
        
         @endforeach
</table>
 
     
        
    
   



