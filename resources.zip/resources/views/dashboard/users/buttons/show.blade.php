<a href="{{ route('dashboard.users.show', $id) }}" class="btn btn-success btn-sm" title="@lang('main.show')">
    <i class="fas fa-eye"></i>
</a>
