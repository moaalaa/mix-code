// States
const state = {};

// Getters
const getters = {};

// Mutations
const mutations = {};

// Actions
const actions = {};

export default {
    state,
    getters,
    mutations,
    actions
}