<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion " id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ dashboardUrl('/') }}">
         {{-- <div class="sidebar-brand-img">
            <img src="{{ asset('/dashboard_assets/img/logo-white.svg') }}" alt="Mix Code Board" title="MixCode Board">
          </div>
          <div class="sidebar-brand-text mx-3">Board</div> --}}
        <div class="mx-3">{{ config('app.name') }}</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item {{ active_route('dashboard.dashboard') }}">
        <a class="nav-link" href="{{ dashboardUrl('/') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>@lang('main.dashboard')</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        @lang('main.users_and_settings')
    </div>

    <!-- Nav Item - Settings -->
    <li class="nav-item {{ active_route('dashboard.settings.*') }}">
        <a class="nav-link" href="{{ route('dashboard.settings.show') }}">
            <i class="fas fa-fw fa-cog"></i>
            <span>@lang('main.general_settings')</span>
        </a>
    </li>

    <!-- Nav Item Users -->
    <li class="nav-item {{ active_route('dashboard.users.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUsers" aria-expanded="true" aria-controls="collapseUsers">
            <i class="fas fa-fw fa-users"></i>
            <span>@lang('main.users')</span>
        </a>
        <div id="collapseUsers" class="collapse" aria-labelledby="headingUsers" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.users.create') }}" href="{{ route('dashboard.users.create') }}">@lang('main.add') @lang('main.users')</a>
                <a class="collapse-item {{ active_route('dashboard.users.index') }}" href="{{ route('dashboard.users.index') }}">@lang('main.show_all') @lang('main.users')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.users.trashed') }}" href="{{ route('dashboard.users.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    {{-- <hr class="sidebar-divider"> --}}
    
    <!-- Heading -->
    {{-- <div class="sidebar-heading">
        @lang('main.location')
    </div> --}}

    <!-- Nav Item Country -->
    {{-- <li class="nav-item {{ active_route('dashboard.countries.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCountries" aria-expanded="true" aria-controls="collapseCountries">
            <i class="fas fa-fw fa-globe"></i>
            <span>@lang('main.countries')</span>
        </a>
        <div id="collapseCountries" class="collapse" aria-labelledby="headingCountries" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.countries.create') }}" href="{{ route('dashboard.countries.create') }}">@lang('main.add') @lang('main.countries')</a>
                <a class="collapse-item {{ active_route('dashboard.countries.index') }}" href="{{ route('dashboard.countries.index') }}">@lang('main.show_all') @lang('main.countries')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.countries.trashed') }}" href="{{ route('dashboard.countries.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li> --}}

    <!-- Nav Item City -->
    {{-- <li class="nav-item {{ active_route('dashboard.cities.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCities" aria-expanded="true" aria-controls="collapseCities">
            <i class="fas fa-fw fa-map-signs"></i>
            <span>@lang('main.cities')</span>
        </a>
        <div id="collapseCities" class="collapse" aria-labelledby="headingCities" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.cities.create') }}" href="{{ route('dashboard.cities.create') }}">@lang('main.add') @lang('main.cities')</a>
                <a class="collapse-item {{ active_route('dashboard.cities.index') }}" href="{{ route('dashboard.cities.index') }}">@lang('main.show_all') @lang('main.cities')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.cities.trashed') }}" href="{{ route('dashboard.cities.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li> --}}

    <!-- Divider -->
    <hr class="sidebar-divider">
    
    <!-- Heading -->
    <div class="sidebar-heading">
        @lang('main.categories_and_companies')
    </div>

    <!-- Nav Item Category -->
    <li class="nav-item {{ active_route('dashboard.categories.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCategories" aria-expanded="true" aria-controls="collapseCategories">
            <i class="fas fa-fw fa-tag"></i>
            <span>@lang('main.categories')</span>
        </a>
        <div id="collapseCategories" class="collapse" aria-labelledby="headingCategories" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.categories.create') }}" href="{{ route('dashboard.categories.create') }}">@lang('main.add') @lang('main.categories')</a>
                <a class="collapse-item {{ active_route('dashboard.categories.index') }}" href="{{ route('dashboard.categories.index') }}">@lang('main.show_all') @lang('main.categories')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.categories.trashed') }}" href="{{ route('dashboard.categories.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li>
    <li class="nav-item {{ active_route('dashboard.companies.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsecompanies" aria-expanded="true" aria-controls="collapsecompanies">
            <i class="fas fa-fw fa-paperclip"></i>
            <span>@lang('main.companies')</span>
        </a>
        <div id="collapsecompanies" class="collapse" aria-labelledby="headingcompanies" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.companies.create') }}" href="{{ route('dashboard.companies.create') }}">@lang('main.add') @lang('main.companies')</a>
                <a class="collapse-item {{ active_route('dashboard.companies.index') }}" href="{{ route('dashboard.companies.index') }}">@lang('main.show_all') @lang('main.companies')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.companies.trashed') }}" href="{{ route('dashboard.companies.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        @lang('main.cards')
    </div>

    <li class="nav-item {{ active_route('dashboard.cards.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsecards" aria-expanded="true" aria-controls="collapsecards">
             <i class="fa fa-gift"></i>
            <span>@lang('main.cards')</span>
        </a>
        <div id="collapsecards" class="collapse" aria-labelledby="headingcards" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.cards.create') }}" href="{{ route('dashboard.cards.create') }}">@lang('main.add') @lang('main.cards')</a>
                <a class="collapse-item {{ active_route('dashboard.cards.index') }}" href="{{ route('dashboard.cards.index') }}">@lang('main.show_all') @lang('main.cards')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.cards.trashed') }}" href="{{ route('dashboard.cards.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li>




    <li class="nav-item {{ active_route('dashboard.orders.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsecardsOrders" aria-expanded="true" aria-controls="collapsecards">
             <i class="fa fa-gift"></i>
            <span>@lang('main.cards_orders')</span>
        </a>
        <div id="collapsecardsOrders" class="collapse" aria-labelledby="headingcards" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.orders.index') }}" href="{{ route('dashboard.orders.index') }}">@lang('main.show_all') @lang('main.orders')</a>
            </div>
        </div>
    </li>

    
    <!-- Nav Item Language -->
    {{-- <li class="nav-item {{ active_route('dashboard.languages.*') }}">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLanguages" aria-expanded="true" aria-controls="collapseLanguages">
            <i class="fas fa-fw fa-language"></i>
            <span>@lang('main.languages')</span>
        </a>
        <div id="collapseLanguages" class="collapse" aria-labelledby="headingLanguages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item {{ active_route('dashboard.languages.create') }}" href="{{ route('dashboard.languages.create') }}">@lang('main.add') @lang('main.languages')</a>
                <a class="collapse-item {{ active_route('dashboard.languages.index') }}" href="{{ route('dashboard.languages.index') }}">@lang('main.show_all') @lang('main.languages')</a>
                <a class="collapse-item text-danger {{ active_route('dashboard.languages.trashed') }}" href="{{ route('dashboard.languages.trashed') }}">@lang('main.trashed')</a>
            </div>
        </div>
    </li> --}}
    
    <!-- Nav Item Language -->


    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    
    <!-- Nav Item - Contacts -->
    <li class="nav-item {{ active_route('dashboard.contacts.*') }}">
        <a class="nav-link" href="{{ route('dashboard.contacts.index') }}">
            <i class="fas fa-fw fa-envelope"></i>
            <span>@lang('main.contacts')</span>
        </a>
    </li>
    
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>