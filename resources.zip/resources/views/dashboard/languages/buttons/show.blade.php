<a href="{{ route('dashboard.languages.show', $id) }}" class="btn btn-success btn-sm" title="@lang('main.show')">
    <i class="fas fa-eye"></i>
</a>
