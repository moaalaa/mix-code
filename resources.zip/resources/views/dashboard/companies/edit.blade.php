@extends('dashboard.layouts.app') 

@section('section', $sectionName)

@section('content')

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{ $sectionName }}</h1>
        
        <div>
            <a href="{{ route('dashboard.companies.show', $company) }}" class="d-sm-inline-block btn btn-sm btn-info shadow-sm">
                <i class="fas fa-eye fa-sm text-white-50"></i> 
                @lang('main.show') {{ $company->name_by_lang }}
            </a>
            
            <a href="{{ route('dashboard.companies.index') }}" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-paperclip fa-sm text-white-50"></i> 
                @lang('main.show_all') @lang('main.companies')
            </a>

        </div>
    </div>
    
    

    <!-- Content Row -->
    <div class="row mb-3">
    
        <div class="col-xl-1 col-md-1"></div>
        <div class="col-xl-12 col-md-12 col-sm-12">
            <div class="company">
                <div class="company-body border-left-info">
                    <div class="company-title font-weight-bold h5 text-center text-info">{{ $sectionName }}</div>
                    <div class="company-text">
                        <form action="{{ route('dashboard.companies.update', $company) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')
    
                            {{-- EN Name --}}
                            <div class="form-group my-4 row">
                                <label class="col-sm-2 col-form-label" for="en_name">@lang('main.en_name')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="text" name="en_name" value="{{ $company->en_name }}" id="en_name" class="form-control @error('en_name') is-invalid @enderror" placeholder="@lang('main.en_name')" required>
                                    
                                    @error('en_name')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            
                            {{-- AR Name --}}
                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="ar_name">@lang('main.ar_name')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="text" name="ar_name" value="{{ $company->ar_name }}" id="ar_name" class="form-control @error('ar_name') is-invalid @enderror" placeholder="@lang('main.ar_name')" required>
                                    
                                    @error('ar_name')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>


                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="email">@lang('main.email')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="email" name="email" value="{{ $company->email }}" id="email" class="form-control @error('email') is-invalid @enderror" placeholder="@lang('main.email')" required>
                                    @error('email')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>


                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="phone">@lang('main.phone')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="number" name="phone" value="{{ $company->phone }}" id="phone" class="form-control @error('phone') is-invalid @enderror" placeholder="@lang('main.phone')" required>
                                    @error('phone')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="en_address">@lang('main.en_address')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="text" name="en_address" value="{{ $company->en_address }}" id="en_address" class="form-control @error('en_address') is-invalid @enderror" placeholder="@lang('main.en_address')" required>
                                    @error('en_address')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            
                            
                            
                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="ar_address">@lang('main.ar_address')<span class="required"></span> </label>
                                <div class="col-sm-10">
                                    <input type="text" name="ar_address" value="{{ $company->ar_address }}" id="ar_address" class="form-control @error('ar_address') is-invalid @enderror" placeholder="@lang('main.ar_address')" required>
                                    @error('ar_address')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>


                            {{-- English Overview --}}
<div class="form-group mb-4 row">
    <label class="col-sm-2 col-form-label" for="en_overview">@lang('main.en_overview')<span class="required"></span> </label>
    <div class="col-sm-10">
        <textarea type="text" name="en_overview" id="en_overview" class="form-control @error('en_overview') is-invalid @enderror" placeholder="@lang('main.en_overview')" required>
            {{ $company->en_overview }}
        </textarea>
        @error('en_overview')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
</div>

{{-- Arabic Overview --}}
<div class="form-group mb-4 row">
    <label class="col-sm-2 col-form-label" for="ar_overview">@lang('main.ar_overview')<span class="required"></span> </label>
    <div class="col-sm-10">
        <textarea type="text" name="ar_overview" id="ar_overview" class="form-control @error('ar_overview') is-invalid @enderror" placeholder="@lang('main.ar_overview')" required>
            {{ $company->ar_overview }}
        </textarea>
        @error('ar_overview')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
</div>





                            <div class="grid d-flex">
    
                            
                                <div class="grid-col grid-col--1"></div>
                                <div class="grid-col grid-col--2 d-sm-none d-md-block"></div>
                                <div class="grid-col grid-col--3 d-sm-none d-lg-block"></div>
                                <div class="grid-col grid-col--4"></div>
                                
                             
                                
                                    <div class="company grid-item image-container">
                                        <img class="company-img portfolio-image" src="{{ $company->mainMediaUrl() }}">
                                            
                                        {{-- <button type="button" class="btn btn-danger btn-sm delete-image" data-id="{{ $company->id }}">
                                            <i class="fas fa-trash"></i>
                                        </button> --}}
                            
                                    </div>
  
                            </div>


                            <div class="form-group mb-4 row">
                                <label class="col-sm-2 col-form-label" for="images">@lang('main.images')</label>
                                <div class="col-sm-10">
                                    <input type="file" name="images" id="images" accept=".png,.jpg,.jpeg" >
                            
                                    @error('images')
                                        <div class="invalid-feedback d-block">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>



                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-info">@lang('main.edit') @lang('main.company')</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    
    </div>
    
@endsection

@section('scripts')
<script src="{{ asset('/dashboard_assets/libs/ckeditor/ckeditor.js') }}" type="text/javascript"></script>
@endsection