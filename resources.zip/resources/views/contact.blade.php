@extends('layouts.app')

@section('content')

<div id="top-page">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="p-title">@lang('site.contact_us')</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">@lang('site.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">@lang('site.contact_us')</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Start Page -->
<div id="p-contact" class="page py-5">
    <div class="container">
        <div class="row">
            <div class="col">
                <form class="form" action="{{ route('contacts.store') }}" method="post">
                    @csrf

                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12">
                            <div class="field-group">
                                <label>@lang('main.name')</label>
                                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                    placeholder="@lang('main.name')" value="{{ old('name') }}" required>

                                @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12">
                            <div class="field-group">
                                <label>@lang('main.email')</label>
                                <input type="email" name="email"
                                    class="form-control @error('email') is-invalid @enderror"
                                    placeholder="@lang('main.email')" value="{{ old('email') }}" required>

                                @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                       
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="field-group">
                                <label>@lang('main.message')</label>
                                <textarea name="message" class="form-control @error('message') is-invalid @enderror"
                                    placeholder="@lang('main.message')" required>{{ old('message') }}</textarea>

                                @error('message')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <button type="submit" class="btn btn-primary btn-send">@lang('site.send')</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="block">
                    <h5>@lang('main.address')</h5>
                    <ul>
                        <li>
                            <p>
                                {{ getSettings()->address }}
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="block">
                    <h5>@lang('main.phone')</h5>

                    @php
                    $phones = explode('-', getSettings()->phone);
                    @endphp

                    <ul>
                        @foreach ($phones as $phone)
                        <li>
                            <p>
                                <a href="tel:{{ $phone }}">{{ $phone }}</a>
                            </p>
                        </li>
                        @endforeach

                    </ul>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="block">
                    <h5>@lang('main.email')</h5>
                    <ul>
                        <li>
                            <p>

                                <a href="mailto:{{ getSettings()->email }}">{{ getSettings()->email }}</a>
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
@endsection