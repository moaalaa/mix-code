@extends('layouts.app')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('/assets/css/main-search.css') }}">
@endsection

@section('content')

<div class="limiter">
  <div class="container-login100">
      <div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
        
              <form  class="form  login100-form validate-form" action="" method="get" >
                  {{-- @csrf --}}
              <span class="login100-form-title p-b-55">
                  <img  class="login-logo" src="{{ getSettings()->mainMediaUrl('intro_image') }}" alt="{{ config('app.name') }}">
              </span>

              <div class="wrap-input100 validate-input m-b-16">
                 <h4>@lang('main.search_box_title') </h4> 
            </div>

              <div class="wrap-input100 validate-input m-b-16" >
                  <input class="input100" type="text"  id='phone' name="phone"  placeholder="@lang('main.phone')" >
                  <span class="focus-input100"></span>
                  <span class="symbol-input100">
                      <span class="lnr lnr-envelope"></span>
                  </span>
              </div>
  
              <div class="container-login100-form-btn p-t-25">
                  <button  id="search" class="login100-form-btn">@lang('main.search')</button>
              </div>

          </form>

         
                 <div id="something">  {{-- @include('userTableInfo') --}}  </div>


               
      </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 


<script>



  $(document).ready(function() {

    $("form").submit(function(e){  e.preventDefault(); });
 

     $('#search').click(function() {

        $.ajaxSetup({
        headers: {
            'X-CSRF-Token': $('meta[name="csrf_token"]').attr('content')
        }
    });
   
 

    var phone =  $("#phone").val();
    
       $.ajax({
              url: " {{ url('/userTableInfo/') }}"  ,
              type: 'GET',
              data: { phone: phone },
              success: function(data)
              {
                  $('#something').html(data);
                  
                   
              }
          });
     });


  });  
  
  


</script>

@endsection
