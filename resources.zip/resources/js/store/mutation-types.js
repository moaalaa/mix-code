// 'X' Module
export const MUTATION_TYPE_NAME = 'mutationTypeValue';