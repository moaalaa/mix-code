<a href="{{ route('dashboard.languages.edit', $id) }}" class="btn btn-info btn-sm" title="@lang('main.edit')">
    <i class="fas fa-edit"></i>    
</a>
