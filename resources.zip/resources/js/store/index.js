import Vue from 'vue';
import Vuex from 'vuex';
// import 'X' from './modules/X';

Vue.use(Vuex);

const store = new Vuex.Store({
    modules: {}
});

export default store;