<template>
    <div>Example Component</div>
</template>

<script>
export default {
    data() {
        return { };
    },
}
</script>