@extends('dashboard.layouts.app')

@section('section', $sectionName)

@section('styles')
    <style>
        .grid-col {
            flex: 1;
            padding: 0 .1em;
        }
    </style>
@endsection

@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">{{ $sectionName }}</h1>
    <div>
        <a href="{{ route('dashboard.cards.edit', $card) }}"
            class="d-sm-inline-block btn btn-sm btn-info shadow-sm">
            <i class="fas fa-edit fa-sm text-white-50"></i>
            @lang('main.edit')
        </a>

        <a href="{{ route('dashboard.cards.destroy',  $card) }}"
            class="d-sm-inline-block btn btn-sm btn-danger shadow-sm" data-toggle="modal"
            data-target="#deleteModel-{{ $card->id }}" title="@lang('main.delete')">
            <i class="fas fa-trash fa-sm text-white-50"></i>
            @lang('main.delete')
        </a>

        <a href="{{ route('dashboard.cards.create') }}" class="d-sm-inline-block btn btn-sm btn-success shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i>
            @lang('main.add') @lang('main.cards')
        </a>

        <a href="{{ route('dashboard.cards.index') }}" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plane fa-sm text-white-50"></i>
            @lang('main.show_all') @lang('main.cards')
        </a>

        @component('dashboard.components.deleteModelForm')
            @slot('id', $card->id )
            @slot('deleteTitle', trans('main.cards') . ' ' . $card->name_by_lang)
            @slot('url', route('dashboard.cards.destroy', $card->id) )
        @endcomponent

    </div>
</div>

<!-- Content Row -->
<div class="row">

    {{-- Basic Info --}}
    <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        <div class="card  border-left-success">

            <div class="card-body">
                <div class="card-title font-weight-bold h5 text-center  row">
                    <div class="card-title col-md-6 col-sm-12 mb-0">@lang('main.created_at'):
                        {{ $card->created_at->calendar() }} </div>
                    <div class="card-title col-md-6 col-sm-12 mb-0">@lang('main.updated_at'):
                        {{ $card->updated_at->calendar() }} </div>
                </div>
                <hr>
                <div class="card-text">
                    <div class="row">

                        @include('dashboard.cards.includes.show._basic_info')
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    {{-- Location Info --}}
    {{-- <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        <div class="card  border-left-success">

            <div class="card-body">
                <div class="card-title font-weight-bold h5 text-center text-success">@lang('main.location_info')</div>
                <div class="card-text">
                    <div class="row">

                        @include('dashboard.cards.includes.show._location_info')
                        
                    </div>
                </div>
            </div>
        </div>
    </div> --}}

    {{-- features Info --}}
    <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        @include('dashboard.cards.includes.show._features_info')
    </div>
    
    {{-- Guests Info --}}
    {{-- <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        <div class="card  border-left-info">
            <div class="card-body">
                <div class="card-title font-weight-bold h5 text-center text-info">@lang('main.guests_info')</div>
                <div class="card-text">
                    <div class="row">

                        @include('dashboard.cards.includes.show._guests_info')
                        
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
    
    {{-- Additional Info --}}
    <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        @include('dashboard.cards.includes.show._additional_info')                
    </div>

    {{-- Media --}}
    <div class="col-xl-12 col-md-12 col-sm-12 mb-3">
        @include('dashboard.cards.includes.show._media')
    </div>

</div>
@endsection


@section('scripts')
    {{-- Colcade --}}
    <script src="{{ asset('/dashboard_assets/libs/colcade/colcade.js') }}" type="text/javascript"></script>
    
    {{-- Colcade Init --}}
    <script>
        new Colcade('.grid', {
            columns: '.grid-col',
            items: '.grid-item'   
        });
    </script>

    {{-- Delete Media --}}
    <script>
        deleteMedia('.delete-image', '{{ route("dashboard.cards.media.destroy", $card) }}');
    </script>
@endsection