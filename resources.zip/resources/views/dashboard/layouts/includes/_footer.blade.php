<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            
            <span>
                {{-- Powred By
                <a target="_blank" href="http://mix-code.com/">
                    Mix Code 
                </a> --}}
            </span>
            
        </div>
    </div>
</footer>