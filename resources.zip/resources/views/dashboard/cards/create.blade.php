@extends('dashboard.layouts.app') 

@section('section', $sectionName)

@section('styles')
    {{-- gijgo-bootstrap-datepicker --}}
    <link href="{{ asset('/dashboard_assets/libs/gijgo-bootstrap-datepicker/css/gijgo.min.css') }}" rel="stylesheet" type="text/css" />

    {{-- Select2 --}}
    <link href="{{ asset('/dashboard_assets/libs/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('/dashboard_assets/libs/select2/css/select2-bootstrap.min.css') }}" rel="stylesheet" type="text/css" />

    @if (isRtl())
        <style>
            .gj-picker-bootstrap div[role=navigator] {
                flex-direction: row-reverse !important;
            }
        </style>
    @endif
@endsection

@section('content')

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{ $sectionName }}</h1>
        <a href="{{ route('dashboard.cards.index') }}" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plane fa-sm text-white-50"></i> 
            @lang('main.show_all') @lang('main.cards')
        </a>
    </div>
    
    <!-- Content Row -->
    <div class="row">
    
        <div class="col-xl-1 col-md-1"></div>
        <div class="col-xl-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-body border-left-info">
                    <div class="card-title font-weight-bold h5 text-center text-info">{{ $sectionName }}</div>
                    <div class="card-text">

                        <form action="{{ route('dashboard.cards.store') }}" method="POST" enctype="multipart/form-data">

                            @csrf
                            
                            @include('dashboard.cards.includes.create._basic_info')
                            
                            <hr>
                            
                            {{-- @include('dashboard.cards.includes.create._location_info')
                            
                            <hr> --}}
                            
                            @include('dashboard.cards.includes.create._features_info')

                            <hr>
                            
                             
                            
                            @include('dashboard.cards.includes.create._additional_info')
                            
                            <hr>
                            
                            @include('dashboard.cards.includes.create._media')
                  
    
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-info">@lang('main.add') @lang('main.cards')</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    {{-- gijgo-bootstrap-datepicker --}}
    <script src="{{ asset('/dashboard_assets/libs/gijgo-bootstrap-datepicker/js/gijgo.min.js') }}" type="text/javascript"></script>
    
    {{-- Select2 --}}
    <script src="{{ asset('/dashboard_assets/libs/select2/js/select2.min.js') }}" type="text/javascript"></script>
    
    {{-- CKeditor --}}
    <script src="{{ asset('/dashboard_assets/libs/ckeditor/ckeditor.js') }}" type="text/javascript"></script>

     <script>
        $('#date_from').datepicker({
            uiLibrary: 'bootstrap4',
            format: 'yyyy-mm-dd',
            modal:true,
            header: true,
        });
        
        $('#date_to').datepicker({
            uiLibrary: 'bootstrap4',
            format: 'yyyy-mm-dd',
            modal:true,
            header: true,
        });
    </script>

<script>
    
    $('#limitations').on('change', function () {
        var limitations = $(this).find('option:selected').val();

  if( limitations == 'limited'){ 
   
     $('#frequency_container').show();
    $('#frequency_container').removeClass("d-none");
    $('#hiddden-fild').remove();

     
     }else{ 
     $('#frequency_container').hide();
         $('#frequency_container').addClass("d-none");
         $('#hiddden-input').append('<input id="hiddden-fild" type="hidden" name="frequency" value="unlimited" /> ');
     }
          
        
    })
</script>
  
@endsection