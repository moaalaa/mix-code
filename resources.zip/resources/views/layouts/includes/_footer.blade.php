<footer id="footer">
    <div class="container">
        <div class="row">
            
             
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="block foot-3">
                   
                    <div class="text-center">
                        <p>
                            &copy; {{ date('Y') }} {{ config('app.name') }}. All Rights Reserved.

                            Powerd By -  <a href="http://www.mix-code.com" target="_blank"> MixCode  </a>
                        </p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</footer>