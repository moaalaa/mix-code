<a href="{{ route('dashboard.users.edit', $id) }}" class="btn btn-info btn-sm" title="@lang('main.edit')">
    <i class="fas fa-edit"></i>    
</a>
